function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(220);
  fill(225,225,0);
  strokeWeight(10);
  ellipse(250,250,500)
  fill(0,0,0);
  ellipse(125,125,125,125);
  fill(225,225,225);
  ellipse(125,100,50,50);
  fill(0,0,0);
  ellipse(375,125,125,125);
  fill(220);
  ellipse(375,100,50,50);
  fill(0,0,0);
  rect(125,325,250,25)
  fill(220);
  rect(140,325,220,25);
  
  
  rect()
}